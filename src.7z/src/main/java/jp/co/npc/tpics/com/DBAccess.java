package jp.co.npc.tpics.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DB接続・切断を行うクラス
 * @author chou
 *
 */
public class DBAccess {

	// ログ出力クラス
	private static final Logger logger = LoggerFactory.getLogger(DBAccess.class);

	// Connection
	private Connection mCon       = null;

	// JDBC Driver
	private String mDbDriver      = null;

	// JDBC URL
	private String mDbUrl         = null;

	// User
	private String mDbUser        = null;

	// Password
	private String mDbPass        = null;

	/**
	 * DB接続用変数の設定
	 * @param dbDriver
	 * @param dbUrl
	 * @param dbUser
	 * @param dbPass
	 */
	public void setConfig(String dbDriver, String dbUrl, String dbUser, String dbPass){
		mDbDriver = dbDriver;
		mDbUrl    = dbUrl;
		mDbUser   = dbUser;
		mDbPass   = dbPass;
	}


	/**
	 * DB接続メソッド
	 * @return
	 * @throws Cp5Exception
	 * @throws Exception
	 */
	public Connection connect() throws TfcpException {
		String msg = "";
		mCon = null;

		try {

			// JDBC Driver 登録
			Class.forName(mDbDriver);

			// DB接続
			mCon = DriverManager.getConnection(mDbUrl, mDbUser, mDbPass);
			// 自動コミットを無効
			mCon.setAutoCommit(false);

		} catch (ClassNotFoundException ex1) {

			// ドライバ登録エラー
			msg = String.format(IMessageInfo.TFCPMSG1001, mDbDriver);
			throw new TfcpException(msg);

		} catch (SQLException ex2) {

			// DB接続に失敗
			msg = String.format(IMessageInfo.TFCPMSG1002, ex2.getErrorCode());

			throw new TfcpException(msg);
		}

		return mCon;
	}

	/**
	 * DB切断メソッド
	 * @return
	 */
	public int disconnect() {

		String msg = "";

		try {

			// DB切断
			if (mCon != null && !mCon.isClosed()) {
				mCon.close();
			}

			return IComConst.JOB_CODE.NORMAL;

		} catch (SQLException ex) {
			// DB切断に失敗
			msg = String.format(IMessageInfo.TFCPMSG1003, ex.getErrorCode());
			logger.debug(msg);

			return IComConst.JOB_CODE.ERROR;
		}
	}

}
