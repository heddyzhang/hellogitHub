package jp.co.npc.tpics.main;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.npc.tpics.com.ComUtil;
import jp.co.npc.tpics.com.IMessageInfo;
import jp.co.npc.tpics.com.OraDBAccess;
import jp.co.npc.tpics.com.SystemEnv;
import jp.co.npc.tpics.com.TfcpException;

public class TfcpMain {
	static {
		try {
			ResourceBundle prop = ResourceBundle.getBundle("tpics_env");
			System.setProperty("LOG_DIR", "c:/logs/" + ComUtil.getCurrentYM());
		} catch (Exception e) {
			e.printStackTrace();
        }
	}

	// ログ出力クラス
	private static final Logger logger = LoggerFactory.getLogger(TfcpMain.class);

	/**
	 * mainメソッド
	 * @param args
	 */
    public static void main(String[] args) {

    	TfcpMain tfcpMain = new TfcpMain();

    	// 処理実行
    	tfcpMain.execute();
    }

	/**
	 * main処理
	 */
    public void execute() {

		OraDBAccess oraAccess = null;
		SystemEnv sysEnv = null;
		Connection oraCon	= null;
		String msg = "";
		boolean rollbackFlg = false;
		String strLogDir = "";

		try {

	        File file = new File("C:/logs/" + ComUtil.getCurrentYM());
	        // ログ出力パス
	        strLogDir = file.getPath();
	        // ログ出力フォルダが存在しない場合
	        if (!file.exists()) {
	        	// ディレクトリが生成されない場合は
	            if (!file.mkdir()) {
	    			msg = String.format(IMessageInfo.TFCPMSG1010, strLogDir);
	    			System.out.println(msg);
	                return;
	            }
	        }
			// ログの配置
			//System.setProperty("LOG_DIR", strLogDir);

			// 環境変数
			sysEnv = new SystemEnv();
			// 環境変数の設定
			sysEnv.setEnv();

			// Oracleアクセスクラス
			oraAccess = new OraDBAccess();

			// Oracle接続情報設定を行う
			oraAccess.setConfig(sysEnv.getOraDriver(), sysEnv.getOraUrl(), sysEnv.getOraUserid(), sysEnv.getOraPassword());
			// DB接続
			oraCon = oraAccess.connect();

			OrderTorokuExec orderTorokuExec = new OrderTorokuExec(oraCon, sysEnv);

			// 注文情報をTPiCSに登録処理
			orderTorokuExec.execute();

			// DB切断
			oraAccess.disconnect();

		} catch (TfcpException e) {

			rollbackFlg = true;
			// 例外キャッチ(TfcpException)
			logger.debug(e.getMessage());

		} catch (Exception e) {

			rollbackFlg = true;
			// 予期しない例外
			msg = String.format(IMessageInfo.TFCPMSG1010, e.getMessage());
			//logger.debug(msg);
		} finally {

			if (rollbackFlg && oraCon != null) {
				try {
					// DBロールバック
					oraCon.rollback();
				} catch (SQLException e) {

					// エラーの場合、メッセージ(CP5J210026)を出力
					msg = String.format(IMessageInfo.TFCPMSG1004, e.getErrorCode());
					System.out.println(msg);
				}
			}

		}

    }
}
