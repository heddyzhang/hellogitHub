package jp.co.npc.tpics.dto;

import lombok.Data;

/**
 * 注文情報明細定義Dto
 * @author chou
 *
 */
@Data
public class OrderInfoDetailDto {

	private int receivedFileID;		// 取込ID

	private String procKbn;				// 処理区分

	private String procStatus;			// 処理ステータス

	private String registryDate;		// 登録日付

	private String seibanCode; 			// 製番コード

	private String seibanName; 			// 製番名

	private String orderNO; 			// 受注No.

	private String billingCode;			// 請求先コード

	private String billingName1;		// 請求先名１

	private String billingName2;		// 請求先名２

	private String customerName1; 		// 得意先名１

	private String itemName; 			// 商品名

	private String itemCode;			// 商品コード

	private String itemName3;			// 商品名３

	private int quantity;				// 数量

	private int unitCost;				// 単位原価

	private String deliveryDate;		// 納品期日

	private String shipToZipCode;		// 直送先郵便番号

	private String shipToAddress1;		// 直送先住所１

	private String shipToAddress2;		// 直送先住所２

	private String shipToName1;			// 直送先名１

	private String shipToName2;			// 直送先名２

	private String shipToStaff;			// 直送先担当者

	private String shipToPrefix;		// 直送先敬称

	private String shipToTEL;			// 直送先担当者

	private String purchaseNO;			// 注文No.

	private String orderDate;			// 受注日付

	private String remarks;				// 備考

	private String modelCode;			// 機種／手配先コード

	private String modelName;			// 機種／手配先名

	private String orderDetailsiID;		// 受注明細ID

	private String modificationDate;	// 修正日付

	private String itemCategoryCode;	// 商品カテゴリコード

	private String itemCategoryName;	// 商品カテゴリ名

}