package jp.co.npc.tpics.com;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ComUtil {

	/**
	 * 現在の日付を取得
	 * @return
	 */
	public static String getCurrentYM() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		return sdf.format(new Date());
	}
}
