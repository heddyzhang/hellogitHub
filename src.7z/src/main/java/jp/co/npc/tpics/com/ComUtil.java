package jp.co.npc.tpics.com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 共通メソッドクラス
 * @author chou
 *
 */
public class ComUtil {

	/**
	 * 現在の月を取得（yyyyMM）
	 * @return
	 */
	public static String getCurrentYM() {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		return sdf.format(new Date());
	}

	/**
	 * 前月を取得
	 * @return
	 */
	public static String getLastYM() {
		Calendar cal = Calendar.getInstance();
		// 月計算
		cal.add(Calendar.MONTH, -1);

		Date lastMonthDate = cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");

		return sdf.format(lastMonthDate);
	}

    /**
     * 現在の日時を取得.
     *
     * @param strFormat	戻値日付のフォーマット
     * @return String strToday 今日の日付
     */
    public static String getCurrentDateStr(String strFormat)
    {
        final SimpleDateFormat sdf = new SimpleDateFormat(strFormat);
        final Date date = new Date();
        final String strToday = sdf.format(date);
        return strToday;
    }

	/**
	 * 日付型の文字列から日付型を変換(yyyy/MM/dd HH:mm)
	 * @param dateInString
	 * @return
	 */
	public static Date formatDateTime(String dateInString) throws Exception {


		Date date = null;
		try {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
			date = sdf.parse(dateInString);
		} catch (ParseException e) {
			throw e;
		}

		return date;

	}

	/**
	 * 日付型の文字列から日付型を変換(yyyy/MM/dd)
	 * @param dateInString
	 * @return
	 */
	public static Date formatDate(String dateInString) throws Exception {

		Date date = null;
		try {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			date = sdf.parse(dateInString);
		} catch (ParseException e) {
			throw e;
		}

		return date;

	}

	/**
	 * 日付比較
	 * @param strDate1
	 * @param strDate2
	 * @return strDate1 > strDate2 => 1 strDate1 < strDate2 => -1 strDate1 = strDate2 => 0
	 * 引数がyyyy-MM-dd hh:mm:ssとして正しくない => 0
	 * @throws Exception
	 */
    public static int dateCheck(String strDate1, String strDate2) {

    	if (isEmpty(strDate1) && isEmpty(strDate2)) return 0;

    	if (isEmpty(strDate1)) return -1;

    	if (isEmpty(strDate2)) return 1;

    	try {
    		strDate1 = strDate1.replace("/", "-");
    		strDate2 = strDate2.replace("/", "-");
	    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
    		Date date1 = sdf.parse(strDate1);
			Date date2 = sdf.parse(strDate2);

	        if (date1.compareTo(date2) > 0) {
	        	return 1;
	        } else if (date1.compareTo(date2) < 0) {
	        	return -1;
	        } else {
	        	return 0;
	        }
		} catch (ParseException e) {
			return 0;
		}
    }

	/**
	 * 現在日付を取得(DB更新用)
	 * @return
	 */
	public static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}

	/**
	 * 文字列が空白かどうか
	 * @param s
	 * @return
	 */
	public static boolean isEmpty(String s) {

		if ((s == null) || (s.trim().length() == 0)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 空白文字列をnullに変換
	 * @param str
	 * @return
	 */
	public static String convEmptyToNv(String str) {

		if (isEmpty(str)){
			return null;
		} else {
			return str;
		}
	}
}
