package jp.co.npc.tpics.dto;

import java.util.Date;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * 注文情報ヘッダ定義Dto
 * @author chou
 *
 */
@Data
@RequiredArgsConstructor
public class OrderInfoHeadDto {

	private final int receivedFileID;

	private String procDate;

	private final String fileName;

	private final int dataCount;

	private final int procCount;

	private final int errCount;

	private Date createdDate;

	private String createdBy;

	private Date updatedDate;

	private String updatedBy;

}
