package jp.co.npc.tpics.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import jp.co.npc.tpics.com.ComUtil;
import jp.co.npc.tpics.com.DBExecutor;
import jp.co.npc.tpics.com.IComConst;
import jp.co.npc.tpics.com.IMessageInfo;
import jp.co.npc.tpics.com.TfcpException;
import jp.co.npc.tpics.dto.CsvInfoDto;
import jp.co.npc.tpics.dto.OrderInfoDetailDto;
import jp.co.npc.tpics.dto.OrderInfoHeadDto;
import jp.co.npc.tpics.dto.XaactDto;

/**
 *  注文情報を登録サービス
 * @author zhang
 *
 */
public class OrderTorokuService {

	// 注文情報CSV定義Dto
	private CsvInfoDto mCsvInfoDto    = null;

	// SQLServerコネクション
	private Connection msSqlConn;

	// Oracleコネクション
	private Connection oraConn;

	public OrderTorokuService(Connection msSqlConn, Connection oraConn) {
		this.msSqlConn = msSqlConn;
		this.oraConn = oraConn;
	}

	/**
	 * 注文情報CSV定義Dto設定
	 * @param csvItems CSV行データ
	 * @throws Exception
	 */
	public void setCsvInfo(String[] csvItems) throws TfcpException{

		String strMsg = "";
		// 注文情報CSV定義Dtoを生成
		mCsvInfoDto = new CsvInfoDto();

		try {
			// 区切
			mCsvInfoDto.setDeliver(csvItems[0]);
			// 登録日付
			mCsvInfoDto.setTorokuDate(csvItems[1]);
			// 製番コード
			mCsvInfoDto.setSeihinCode(csvItems[2]);
			// 製番名
			mCsvInfoDto.setSeibanName(csvItems[3]);
			// 受注No.
			mCsvInfoDto.setOrderNO(csvItems[4]);
			// 請求先コード
			mCsvInfoDto.setSeikyuCode(csvItems[5]);
			// 請求先名１
			mCsvInfoDto.setSeikyuName1(csvItems[6]);
			// 請求先名２
			mCsvInfoDto.setSeikyuName2(csvItems[7]);
			// 得意先名１
			mCsvInfoDto.setTokuisakiName1(csvItems[8]);
			// 商品名
			mCsvInfoDto.setShohinName(csvItems[9]);
			// 商品コード
			mCsvInfoDto.setItemCode(csvItems[10]);
			// 商品名３
			mCsvInfoDto.setShohinName3(csvItems[11]);
			// 数量
			mCsvInfoDto.setSuryo(csvItems[12]);
			// 単位原価
			mCsvInfoDto.setTaniGenka(csvItems[13]);
			// 納品期日
			mCsvInfoDto.setNohinDate(csvItems[14]);
			// 直送先郵便番号
			mCsvInfoDto.setChososakiZip(csvItems[15]);
			// 直送先住所１
			mCsvInfoDto.setChososakiAddress1(csvItems[16]);
			// 直送先住所２
			mCsvInfoDto.setChososakiAddress2(csvItems[17]);
			// 直送先名１
			mCsvInfoDto.setChososakiName1(csvItems[18]);
			// 直送先名２
			mCsvInfoDto.setChososakiName2(csvItems[19]);
			// 直送先担当者
			mCsvInfoDto.setChososakiTanto(csvItems[20]);
			// 直送先敬称
			mCsvInfoDto.setChososakiMr(csvItems[21]);
			// 直送先電話番号
			mCsvInfoDto.setChososakiTel(csvItems[22]);
			// 注文No.
			mCsvInfoDto.setPurchaseNO(csvItems[23]);
			// 受注日付
			mCsvInfoDto.setOrderDate(csvItems[24]);
			// 備考
			mCsvInfoDto.setBikou(csvItems[25]);
			// 機種／手配先コード
			mCsvInfoDto.setModelArrangeCode(csvItems[26]);
			// 機種／手配先名
			mCsvInfoDto.setModelArrangeName(csvItems[27]);
			// 受注明細ID
			mCsvInfoDto.setJyuchuDetailID(csvItems[28]);
			// 修正日付
			mCsvInfoDto.setModificationDate(csvItems[29]);
			// 商品カテゴリコード
			mCsvInfoDto.setShohinCategoryCode(csvItems[30]);
			// 商品カテゴリ名
			mCsvInfoDto.setShohinCategoryName(csvItems[31]);

		} catch (Exception e) {
			strMsg = String.format(IMessageInfo.TFCPMSG1023, e.getMessage());
			throw new TfcpException(strMsg);
		}
	}

	/**
	 * CSV注文情報から注文情報明細に変換
	 * @return
	 */
	public OrderInfoDetailDto convOrderInfoDetail(int receivedFildID, String procKbn, String procStatus) throws TfcpException{

		String strMsg = "";
		OrderInfoDetailDto orderInfoDetail = null;

		try {
			orderInfoDetail = new OrderInfoDetailDto();
			// 取込ID
			orderInfoDetail.setReceivedFileID(receivedFildID);
			// 処理区分
			orderInfoDetail.setProcKbn(procKbn);
			// 処理ステータス
			orderInfoDetail.setProcStatus(procStatus);
			// 登録日付;
			orderInfoDetail.setRegistryDate(mCsvInfoDto.getTorokuDate());
			// 製番コード
			orderInfoDetail.setSeibanCode(mCsvInfoDto.getSeihinCode());
			// 製番名
			orderInfoDetail.setSeibanName(mCsvInfoDto.getSeibanName());
			// 受注No.
			orderInfoDetail.setOrderNO(mCsvInfoDto.getOrderNO());
			// 請求先コード
			orderInfoDetail.setBillingCode(mCsvInfoDto.getSeikyuCode());
			// 請求先名１
			orderInfoDetail.setBillingName1(mCsvInfoDto.getSeikyuName1());
			// 請求先名２
			orderInfoDetail.setBillingName2(mCsvInfoDto.getSeikyuName2());
			// 得意先名１
			orderInfoDetail.setCustomerName1(mCsvInfoDto.getTokuisakiName1());
			// 商品名
			orderInfoDetail.setItemName(mCsvInfoDto.getShohinName());
			// 商品コード
			orderInfoDetail.setItemCode(mCsvInfoDto.getItemCode());
			// 商品名３
			orderInfoDetail.setItemName3(mCsvInfoDto.getShohinName3());
			// 数量
			orderInfoDetail.setQuantity(Integer.parseInt(mCsvInfoDto.getSuryo()));
			// 単位原価
			orderInfoDetail.setUnitCost(Integer.parseInt(mCsvInfoDto.getTaniGenka()));
			// 納品期日
			orderInfoDetail.setDeliveryDate(mCsvInfoDto.getNohinDate());
			// 直送先郵便番号
			orderInfoDetail.setShipToZipCode(mCsvInfoDto.getChososakiZip());
			// 直送先住所１
			orderInfoDetail.setShipToAddress1(mCsvInfoDto.getChososakiAddress1());
			// 直送先住所２
			orderInfoDetail.setShipToAddress2(mCsvInfoDto.getChososakiAddress2());
			// 直送先名１
			orderInfoDetail.setShipToName1(mCsvInfoDto.getChososakiName1());
			// 直送先名２
			orderInfoDetail.setShipToName2(mCsvInfoDto.getChososakiName2());
			// 直送先担当者
			orderInfoDetail.setShipToStaff(mCsvInfoDto.getChososakiTanto());
			// 直送先敬称
			orderInfoDetail.setShipToPrefix(mCsvInfoDto.getChososakiMr());
			// 直送先電話番号
			orderInfoDetail.setShipToTEL(mCsvInfoDto.getChososakiTel());
			// 注文No.
			orderInfoDetail.setPurchaseNO(mCsvInfoDto.getPurchaseNO());
			// 受注日付
			orderInfoDetail.setOrderDate(mCsvInfoDto.getOrderDate());
			// 備考
			orderInfoDetail.setRemarks(mCsvInfoDto.getBikou());
			// 機種／手配先コード
			orderInfoDetail.setModelCode(mCsvInfoDto.getModelArrangeCode());
			// 機種／手配先名
			orderInfoDetail.setModelName(mCsvInfoDto.getModelArrangeName());
			// 受注明細ID
			orderInfoDetail.setOrderDetailsiID(mCsvInfoDto.getJyuchuDetailID());
			// 修正日付
			orderInfoDetail.setModificationDate(mCsvInfoDto.getModificationDate());
			// 商品カテゴリコード
			orderInfoDetail.setItemCategoryCode(mCsvInfoDto.getShohinCategoryCode());
			// 商品カテゴリ名
			orderInfoDetail.setItemCategoryName(mCsvInfoDto.getShohinCategoryName());

			return orderInfoDetail;

		} catch (Exception e) {
			strMsg = String.format(IMessageInfo.TFCPMSG1024, e.getMessage());
			throw new TfcpException(strMsg);
		}
	}

	/**
	 * 注文情報明細からXAACT(TPICS_DB)に変換
	 * @return
	 */
	public XaactDto convXaact(String ProcKbn, OrderInfoDetailDto orderInfoDetailDto) throws TfcpException{

		String strMsg = "";
		XaactDto xaactDto = null;
		int seda = 1;

		try {

			// 枝番を取得
			if (IComConst.PROC_KBN.MOD.equals(ProcKbn)) {
				// 注番とアイテムコードをキーに、枝番を取得する
				seda = getSedaTPiCS(orderInfoDetailDto.getOrderNO(), orderInfoDetailDto.getItemCode());
			} else {
				// TODO
			}

			xaactDto = new XaactDto();
			// データ区分
			xaactDto.setDkubu(orderInfoDetailDto.getProcKbn());
			// ステータス
			xaactDto.setAstatus(Integer.valueOf(orderInfoDetailDto.getProcStatus()));
			// 注番
			xaactDto.setPorder(orderInfoDetailDto.getOrderNO());
			// 枝番
			xaactDto.setPeda(seda);
			// アイテムコード
			xaactDto.setCode(orderInfoDetailDto.getItemCode());
			// 得意先コード
			xaactDto.setCust(orderInfoDetailDto.getBillingCode());
			// 指定納期日
			xaactDto.setCdate(orderInfoDetailDto.getDeliveryDate());
			// 受注数量
			xaactDto.setCvol(orderInfoDetailDto.getQuantity());
			// 計画数量
			xaactDto.setKvol(orderInfoDetailDto.getQuantity());
			// 受注単価
			xaactDto.setPrice(orderInfoDetailDto.getUnitCost());
			// 納品場所コード
			xaactDto.setNouba(orderInfoDetailDto.getShipToName1());
			// 受注日
			xaactDto.setJdate(orderInfoDetailDto.getOrderDate());
			// 営業担当者
			xaactDto.setEigyou(orderInfoDetailDto.getShipToStaff());
			// 登録日
			xaactDto.setInputdate(ComUtil.getCurrentDateStr(IComConst.DATE_FORMAT_PTN_DB));
			// 登録者
			xaactDto.setInputuser(IComConst.LOGIN_USER);

			return xaactDto;

		} catch (Exception e) {
			strMsg = String.format(IMessageInfo.TFCPMSG1025, e.getMessage());
			throw new TfcpException(strMsg);
		}
	}

	/**
	 * 取込対象かどうかをチェック
	 * @return
	 * @throws TfcpException
	 * @throws Exception
	 */
	public int checkData() throws TfcpException, Exception {
		String strMsg = "";
		Object obj = null;
		DBExecutor msSqlExecutor = new DBExecutor(msSqlConn);
		StringBuffer sb = new StringBuffer();
		String modificationDate = "";
		List<Map<String,Object>> resultlist = null;

		try {
			// 修正日付を取得するSQL文を作成
			sb.append("SELECT\n");
			sb.append("  MODIFICATIONDATE \n");
			sb.append("FROM\n");
			sb.append("  ORDER_INFO_DETAIL D \n");
			sb.append("WHERE\n");
			sb.append("  ORDERNO = ? \n");
			sb.append("  AND ITEMCODE = ? \n");
			sb.append("  AND RECEIVEDFILEID = ( \n");
			sb.append("    SELECT\n");
			sb.append("      MAX(RECEIVEDFILEID) \n");
			sb.append("    FROM\n");
			sb.append("      ORDER_INFO_DETAIL \n");
			sb.append("    WHERE\n");
			sb.append("      ORDERNO = ? \n");
			sb.append("      AND ITEMCODE = ? \n");
			sb.append("  );");

			// 受注No
			String orderNo = mCsvInfoDto.getOrderNO();
			// 商品コード
			String itemCode = mCsvInfoDto.getItemCode();
			// 修正日付を取得
			resultlist = msSqlExecutor.getResultList(sb.toString(), orderNo, itemCode, orderNo, itemCode);

			// 既にデータが存在した場合
			if (resultlist.size() > 0) {
				// 修正日付を取得
				obj =((Map<String, Object>) resultlist.get(0)).get("MODIFICATIONDATE");
				modificationDate = obj == null ? null : obj.toString();
				// 修正日付より未来の場合
				if (ComUtil.dateCheck(mCsvInfoDto.getModificationDate(), modificationDate) > 0) {
					// 修正
					return IComConst.SHORI_KBN.MOD;
				} else {
					// 登録対象外
					return IComConst.SHORI_KBN.NA;
				}
			}

		} catch (SQLException ex1) {
			strMsg = String.format(IMessageInfo.TFCPMSG1034, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}

		// 新規
		return IComConst.SHORI_KBN.NEW;
	}
	/**
	 * 注文情報明細を登録
	 * @param receivedFildID
	 * @param procKbn
	 * @param procStatus
	 * @throws TfcpException
	 * @throws Exception
	 */
	public void insertOrderDetail(OrderInfoDetailDto orderInfoDetail) throws TfcpException, Exception{

		String strMsg = "";
		PreparedStatement stmt = null;
		DBExecutor msSqlExecutor = new DBExecutor(msSqlConn);

		try {

			// 注文情報明細SQL文を作成
			StringBuffer sb = new StringBuffer();
			sb.append(" INSERT INTO ORDER_INFO_DETAIL");
			sb.append("    (ReceivedFileID");
			sb.append("    ,ProcKbn");
			sb.append("    ,ProcStatus");
			sb.append("    ,RegistryDate");
			sb.append("    ,SeibanCode");
			sb.append("    ,SeibanName");
			sb.append("    ,OrderNO");
			sb.append("    ,BillingCode");
			sb.append("    ,BillingName1");
			sb.append("    ,BillingName2");
			sb.append("    ,CustomerName1");
			sb.append("    ,ItemName");
			sb.append("    ,ItemCode");
			sb.append("    ,ItemName3");
			sb.append("    ,Quantity");
			sb.append("    ,UnitCost");
			sb.append("    ,DeliveryDate");
			sb.append("    ,ShipToZipCode");
			sb.append("    ,ShipToAddress1");
			sb.append("    ,ShipToAddress2");
			sb.append("    ,ShipToName1");
			sb.append("    ,ShipToName2");
			sb.append("    ,ShipToStaff");
			sb.append("    ,ShipToPrefix");
			sb.append("    ,ShipToTEL");
			sb.append("    ,PurchaseNO");
			sb.append("    ,OrderDate");
			sb.append("    ,Remarks");
			sb.append("    ,ModelCode");
			sb.append("    ,ModelName");
			sb.append("    ,OrderDetailsiID");
			sb.append("    ,ModificationDate");
			sb.append("    ,ItemCategoryCode");
			sb.append("    ,ItemCategoryName");
			sb.append("    )");
			sb.append(" VALUES");
			sb.append("    (?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    )");
			// 実行するSQL文とパラメータを指定する
			stmt = msSqlConn.prepareStatement(sb.toString());
			// シーケンス
			stmt.setInt(1, orderInfoDetail.getReceivedFileID());
			// 処理区分
			stmt.setString(2, orderInfoDetail.getProcKbn());
			// 処理ステータス
			stmt.setString(3, orderInfoDetail.getProcStatus());
			// 登録日付
			stmt.setTimestamp(4, new Timestamp(ComUtil.formatDateTime(orderInfoDetail.getRegistryDate()).getTime()));
			// 製番コード
			stmt.setString(5, orderInfoDetail.getSeibanCode());
			// 製番名
			stmt.setString(6, orderInfoDetail.getSeibanName());
			// 受注No.
			stmt.setString(7, orderInfoDetail.getOrderNO());
			// 請求先コード
			stmt.setString(8, orderInfoDetail.getBillingCode());
			// 請求先名１
			stmt.setString(9, orderInfoDetail.getBillingName1());
			// 請求先名２（非必須）
			stmt.setString(10, orderInfoDetail.getBillingName2());
			// 得意先名１
			stmt.setString(11, orderInfoDetail.getCustomerName1());
			// 商品名
			stmt.setString(12, orderInfoDetail.getItemName());
			// 商品コード
			stmt.setString(13, orderInfoDetail.getItemCode());
			// 商品名３
			stmt.setString(14, orderInfoDetail.getItemName3());
			// 数量
			stmt.setInt(15, orderInfoDetail.getQuantity());
			// 単位原価
			stmt.setInt(16, orderInfoDetail.getUnitCost());
			// 納品期日
			stmt.setDate(17, new Date(ComUtil.formatDate(orderInfoDetail.getDeliveryDate()).getTime()));
			// 直送先郵便番号
			stmt.setString(18, orderInfoDetail.getShipToZipCode());
			// 直送先住所１
			stmt.setString(19, orderInfoDetail.getShipToAddress1());
			// 直送先住所２
			stmt.setString(20, orderInfoDetail.getShipToAddress2());
			// 直送先名１
			stmt.setString(21, orderInfoDetail.getShipToName1());
			// 直送先名２
			stmt.setString(22, orderInfoDetail.getShipToName2());
			// 直送先担当者
			stmt.setString(23, orderInfoDetail.getShipToStaff());
			// 直送先敬称
			stmt.setString(24, orderInfoDetail.getShipToPrefix());
			// 直送先電話番号
			stmt.setString(25, orderInfoDetail.getShipToTEL());
			// 注文No.（非必須）
			stmt.setString(26, orderInfoDetail.getPurchaseNO());
			// 受注日付
			stmt.setDate(27, new Date(ComUtil.formatDate(orderInfoDetail.getOrderDate()).getTime()));
			// 備考（非必須）
			stmt.setString(28, orderInfoDetail.getRemarks());
			// 機種／手配先コード
			stmt.setString(29, orderInfoDetail.getModelCode());
			// 機種／手配先名
			stmt.setString(30, orderInfoDetail.getModelName());
			// 受注明細ID
			stmt.setString(31, orderInfoDetail.getOrderDetailsiID());
			// 修正日付（非必須）
			String strModifiedDate = orderInfoDetail.getModificationDate();
			// 修正日付が空白の場合
			if (ComUtil.isEmpty(strModifiedDate)) {
				stmt.setNull(32, java.sql.Types.TIMESTAMP);
			// 修正日付が空白以外の場合
			} else {
				stmt.setTimestamp(32, new Timestamp(ComUtil.formatDateTime(orderInfoDetail.getModificationDate()).getTime()));
			}
			// 商品カテゴリコード
			stmt.setString(33, orderInfoDetail.getItemCategoryCode());
			// 商品カテゴリ名
			stmt.setString(34, orderInfoDetail.getItemCategoryName());

			// 注文情報明細登録を実行する
			msSqlExecutor.executeStmt(stmt);

		} catch (SQLException ex1) {
			// データベースエラー
			strMsg = String.format(IMessageInfo.TFCPMSG1032, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}

	}

	/**
	 * 注文情報ヘッダを登録
	 * @param receivedFildID
	 * @throws TfcpException
	 * @throws Exception
	 */
	public void insertOrderHead(OrderInfoHeadDto orderInfoHead) throws TfcpException, Exception{
		String strMsg = "";
		PreparedStatement stmt = null;
		DBExecutor msSqlExecutor = new DBExecutor(msSqlConn);

		try {
			// 注文情報明細SQL文を作成
			StringBuffer sb = new StringBuffer();
			sb.append(" INSERT INTO ORDER_INFO_HEAD");
			sb.append("    (ReceivedFileID");
			sb.append("    ,ProcDate");
			sb.append("    ,FileName");
			sb.append("    ,DataCount");
			sb.append("    ,ProcCount");
			sb.append("    ,ErrCount");
			sb.append("    ,CreatedDate");
			sb.append("    ,CreatedBy");
			sb.append("    )");
			sb.append(" VALUES");
			sb.append("    (?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    )");

			// 実行するSQL文とパラメータを指定する
			stmt = msSqlConn.prepareStatement(sb.toString());

			// シーケンス
			stmt.setInt(1, orderInfoHead.getReceivedFileID());
			// 処理日
			stmt.setTimestamp(2, ComUtil.getCurrentTimeStamp());
			// ファイル名
			stmt.setString(3, orderInfoHead.getFileName());
			// 件数
			stmt.setInt(4, orderInfoHead.getDataCount());
			// 処理件数
			stmt.setInt(5, orderInfoHead.getProcCount());
			// エラー件数
			stmt.setInt(6, orderInfoHead.getErrCount());
			// 登録日
			stmt.setTimestamp(7, ComUtil.getCurrentTimeStamp());
			// 登録者
			stmt.setString(8, IComConst.LOGIN_USER);

			// 注文情報ヘッダ登録を実行する
			msSqlExecutor.executeStmt(stmt);

		}catch (SQLException ex1) {
			// データベースエラー
			strMsg = String.format(IMessageInfo.TFCPMSG1033, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}
	}

	/**
	 * TPiCS DBを登録
	 * @param xaactDto
	 * @throws TfcpException
	 * @throws Exception
	 */
	public void insertXaact(XaactDto xaactDto) throws TfcpException, Exception{
		String strMsg = "";
		PreparedStatement stmt = null;
		DBExecutor oraExecutor = new DBExecutor(oraConn);

		try {
			// 注文情報明細SQL文を作成
			StringBuffer sb = new StringBuffer();
			sb.append(" INSERT INTO XAACT");
			sb.append("    (DKUBU");
			sb.append("    ,ASTATUS");
			sb.append("    ,PORDER");
			sb.append("    ,PEDA");
			sb.append("    ,CODE");
			sb.append("    ,CUST");
			sb.append("    ,CDATE");
			sb.append("    ,CVOL");
			sb.append("    ,KVOL");
			sb.append("    ,PRICE");
			sb.append("    ,NOUBA");
			sb.append("    ,JDATE");
			sb.append("    ,EIGYOU");
			sb.append("    ,INPUTDATE");
			sb.append("    ,INPUTUSER");
			sb.append("    )");
			sb.append(" VALUES");
			sb.append("    (?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    ,?");
			sb.append("    )");

			// 実行するSQL文とパラメータを指定する
			stmt = oraConn.prepareStatement(sb.toString());

			// データ区分
			stmt.setString(1, xaactDto.getDkubu());
			// ステータス
			stmt.setInt(2, xaactDto.getAstatus());
			// 注番
			stmt.setString(3, xaactDto.getPorder());
			// 枝番
			stmt.setInt(4, xaactDto.getPeda());
			// アイテムコード
			stmt.setString(5, xaactDto.getCode());
			// 得意先コード
			stmt.setString(6, xaactDto.getCust());
			// 指定納期日
			stmt.setString(7, xaactDto.getCdate());
			// 受注数量
			stmt.setInt(8, xaactDto.getCvol());
			// 計画数量
			stmt.setInt(9, xaactDto.getKvol());
			// 受注単価
			stmt.setInt(10, xaactDto.getPrice());
			// 納品場所コード
			stmt.setString(11, xaactDto.getNouba());
			// 受注日
			stmt.setString(12, xaactDto.getJdate());
			// 営業担当者
			stmt.setString(13, xaactDto.getEigyou());
			// 登録日
			stmt.setString(14, xaactDto.getInputdate());
			// 登録者
			stmt.setString(15, xaactDto.getInputuser());

			// 注文情報ヘッダ登録を実行する
			oraExecutor.executeStmt(stmt);

		}catch (SQLException ex1) {
			// データベースエラー
			strMsg = String.format(IMessageInfo.TFCPMSG1033, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}
	}

	/**
	 * シーケンスファイルＩＤを取得
	 * @return
	 */
	public int getReceivedFileID() throws TfcpException, Exception{

		String strMsg = "";
		int receivedFileId = 0;
		DBExecutor msSqlExecutor = new DBExecutor(msSqlConn);

		try {
			String sql = "SELECT NEXT VALUE FOR RECEIVED_FILE_ID_SEQ";
			receivedFileId =Integer.parseInt(String.valueOf(msSqlExecutor.getSingleValue(sql)));

		} catch (SQLException ex1) {
			// データベースエラー
			strMsg = String.format(IMessageInfo.TFCPMSG1031, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}
		return receivedFileId;
	}

	/**
	 * TPiCS DBを検索し、SEDAを取得
	 * @param orderNo
	 * @param itemCode
	 * @return
	 * @throws TfcpException
	 * @throws Exception
	 */
	public int getSedaTPiCS(String orderNo, String itemCode) throws TfcpException, Exception{

		String strMsg = "";
		int seda = 1;
		DBExecutor oraExecutor = new DBExecutor(oraConn);
		List<Map<String,Object>> list = null;

		try {

			// 受注テーブル(XRECE)を検索し、枝番を取得する
			String sql = "SELECT SEDA FROM XRECE WHERE SORDER = ? AND CODE = ?";
			// 結果リストを取得
			list = oraExecutor.getResultList(sql, orderNo, itemCode);

			// データが存在した場合
			if (list.size() > 0) {

				// 枝番
				seda = Integer.parseInt(((Map<String, Object>) list.get(0)).get("SEDA").toString());
				return seda;
			}
		} catch (SQLException ex1) {
			// データベースエラー
			strMsg = String.format(IMessageInfo.TFCPMSG1035, ex1.getErrorCode());
			throw new TfcpException(strMsg);
		} catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		}

		return seda;
	}
}
