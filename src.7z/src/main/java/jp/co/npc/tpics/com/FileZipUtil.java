package jp.co.npc.tpics.com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 共通ファイル操作クラス
 * @author chou
 *
 */
public class FileZipUtil {

	List<String> filesListInDir = new ArrayList<String>();

	/**
	 * フォルダを圧縮
	 * @param zipFile
	 */
	public void zipDirectory(String srcFolder, String outZipFile) {

		try {

			File srcDir = new File(srcFolder);
			populateFilesList(srcDir);
			FileOutputStream fos = new FileOutputStream(outZipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);
			for (String filePath : filesListInDir) {
				//System.out.println("Zipping " + filePath);

				// 相対パスを設定
				ZipEntry ze = new ZipEntry(filePath.substring(srcDir.getAbsolutePath().length() + 1, filePath.length()));
				zos.putNextEntry(ze);

				FileInputStream fis = new FileInputStream(filePath);
				byte[] buffer = new byte[1024];
				int len;
				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				zos.closeEntry();
				fis.close();
			}
			zos.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
     * ファイルリストを作成
     * @param dir
     * @throws IOException
     */
    private void populateFilesList(File dir) throws IOException {
        File[] files = dir.listFiles();
        for(File file : files){
            if(file.isFile()) filesListInDir.add(file.getAbsolutePath());
            else populateFilesList(file);
        }
    }

    /**
     * 指定したフォルダ下のファイルをコピーする
     * @param srcFolderPath
     * @param destFolderPath
     * @throws IOException
     */
	public static void copyFolder(File srcFolderPath, File destFolderPath) throws IOException {

		if (!srcFolderPath.isDirectory()) {

			InputStream in = new FileInputStream(srcFolderPath);
			OutputStream out = new FileOutputStream(destFolderPath);
			byte[] buffer = new byte[1024];
			int length;

			while ((length = in.read(buffer)) > 0) {

				out.write(buffer, 0, length);
			}

			in.close();
			out.close();
			//System.out.println("File copied from " + srcFolderPath + " to " + destFolderPath + " successfully");

		} else {

			if (!destFolderPath.exists()) {

				destFolderPath.mkdir();
				//System.out.println("Directory copied from " + srcFolderPath + "  to " + destFolderPath + " successfully");
			}

			String folder_contents[] = srcFolderPath.list();

			for (String file : folder_contents) {

				File srcFile = new File(srcFolderPath, file);
				File destFile = new File(destFolderPath, file);

				// 再帰
				copyFolder(srcFile, destFile);

			}
		}
	}

}
