package jp.co.npc.tpics.com;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class SystemEnv {

	private static final String properties_file = "tpics_env";    // プロパティファイル名

	private String oraDriver      = "";	// JDBC ORACLE Driver

	private String oraUrl         = "";	// JDBC ORACLE URL

	private String oraUserid      = "";	// JDBC ORACLE DB UserID

	private String oraPassword    = "";	// JDBC ORACLE DB Password

	private String csvInputFolder   = "";	// JDBC ORACLE Driver

	/**
	 * 環境変数設定メソッド
	 * @throws Exception
	 */
    public void setEnv() throws TfcpException {

    	String msg = "";

		try {

			ResourceBundle Rb = ResourceBundle.getBundle(properties_file);
			oraDriver		= Rb.getString("DB.Oracle.Driver");
			oraUrl			= Rb.getString("DB.Oracle.Url");
			oraUserid		= Rb.getString("DB.Oracle.Userid");
			oraPassword		= Rb.getString("DB.Oracle.Password");
			csvInputFolder	= Rb.getString("Folder.OrderCsv.Input");

		} catch (MissingResourceException e) {

			// リソースが見つかりません
			msg = String.format(IMessageInfo.TFCPMSG1011, properties_file);
			throw new TfcpException(msg);

		} catch (ClassCastException e) {

			// 環境変数取得エラー
			msg = String.format(IMessageInfo.TFCPMSG1012);
			throw new TfcpException(msg);
		}
    }

	/**
	 * @return oraDriver
	 */
	public String getOraDriver() {
		return oraDriver;
	}

	/**
	 * @return oraUrl
	 */
	public String getOraUrl() {
		return oraUrl;
	}

	/**
	 * @return oraUserid
	 */
	public String getOraUserid() {
		return oraUserid;
	}

	/**
	 * @return oraPassword
	 */
	public String getOraPassword() {
		return oraPassword;
	}

	/**
	 * @return csvInputFolder
	 */
	public String getCsvInputFolder() {
		return csvInputFolder;
	}

	/**
	 * @param oraDriver セットする oraDriver
	 */
	public void setOraDriver(String oraDriver) {
		this.oraDriver = oraDriver;
	}

	/**
	 * @param oraUrl セットする oraUrl
	 */
	public void setOraUrl(String oraUrl) {
		this.oraUrl = oraUrl;
	}

	/**
	 * @param oraUserid セットする oraUserid
	 */
	public void setOraUserid(String oraUserid) {
		this.oraUserid = oraUserid;
	}

	/**
	 * @param oraPassword セットする oraPassword
	 */
	public void setOraPassword(String oraPassword) {
		this.oraPassword = oraPassword;
	}

	/**
	 * @param csvInputFolder セットする csvInputFolder
	 */
	public void setCsvInputFolder(String csvInputFolder) {
		this.csvInputFolder = csvInputFolder;
	}


}
