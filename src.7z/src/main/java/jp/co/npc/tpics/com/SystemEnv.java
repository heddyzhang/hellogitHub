package jp.co.npc.tpics.com;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * 環境変数を設定するクラス
 * @author chou
 *
 */
public class SystemEnv {

	private static final String properties_file = "tpics_env";    // プロパティファイル名

	private String msSqlDriver		= "";	// JDBC SQLServer Driver

	private String msSqlUrl			= "";	// JDBC SQLServer URL

	private String msSqlUserid		= "";	// JDBC SQLServer DB UserID

	private String msSqlPassword	= "";	// JDBC SQLServer DB Password

	private String oraDriver		= "";	// JDBC ORACLE Driver

	private String oraUrl			= "";	// JDBC ORACLE URL

	private String oraUserid		= "";	// JDBC ORACLE DB UserID

	private String oraPassword		= "";	// JDBC ORACLE DB Password

	private String csvInputFolder	= "";	// JDBC ORACLE Driver

	private String logBaseDir		= "";	// Log Base Dir

	/**
	 * 環境変数設定メソッド
	 * @throws Exception
	 */
    public void setEnv() throws TfcpException {

    	String msg = "";

		try {

			ResourceBundle Rb = ResourceBundle.getBundle(properties_file);
			logBaseDir		= Rb.getString("Log.Base.Dir");
			msSqlDriver		= Rb.getString("DB.MsSQL.Driver");
			msSqlUrl		= Rb.getString("DB.MsSQL.Url");
			msSqlUserid		= Rb.getString("DB.MsSQL.Userid");
			msSqlPassword	= Rb.getString("DB.MsSQL.Password");
			oraDriver		= Rb.getString("DB.Oracle.Driver");
			oraUrl			= Rb.getString("DB.Oracle.Url");
			oraUserid		= Rb.getString("DB.Oracle.Userid");
			oraPassword		= Rb.getString("DB.Oracle.Password");
			csvInputFolder	= Rb.getString("Folder.OrderCsv.Input");

		} catch (MissingResourceException e) {

			// リソースが見つかりません
			msg = String.format(IMessageInfo.TFCPMSG1011, properties_file);
			throw new TfcpException(msg);

		} catch (ClassCastException e) {

			// TODO
			// 環境変数取得エラー
			msg = String.format(IMessageInfo.TFCPMSG1012);
			throw new TfcpException(msg);
		}
    }

	/**
	 * @return msSqlDriver
	 */
	public String getMsSqlDriver() {
		return msSqlDriver;
	}

	/**
	 * @return msSqlUrl
	 */
	public String getMsSqlUrl() {
		return msSqlUrl;
	}

	/**
	 * @return msSqlUserid
	 */
	public String getMsSqlUserid() {
		return msSqlUserid;
	}

	/**
	 * @return msSqlPassword
	 */
	public String getMsSqlPassword() {
		return msSqlPassword;
	}

	/**
	 * @return oraDriver
	 */
	public String getOraDriver() {
		return oraDriver;
	}

	/**
	 * @return oraUrl
	 */
	public String getOraUrl() {
		return oraUrl;
	}

	/**
	 * @return oraUserid
	 */
	public String getOraUserid() {
		return oraUserid;
	}

	/**
	 * @return oraPassword
	 */
	public String getOraPassword() {
		return oraPassword;
	}

	/**
	 * @return csvInputFolder
	 */
	public String getCsvInputFolder() {
		return csvInputFolder;
	}

	/**
	 * @return logBaseDir
	 */
	public String getLogBaseDir() {
		return logBaseDir;
	}

	/**
	 * @param msSqlDriver セットする msSqlDriver
	 */
	public void setMsSqlDriver(String msSqlDriver) {
		this.msSqlDriver = msSqlDriver;
	}

	/**
	 * @param msSqlUrl セットする msSqlUrl
	 */
	public void setMsSqlUrl(String msSqlUrl) {
		this.msSqlUrl = msSqlUrl;
	}

	/**
	 * @param msSqlUserid セットする msSqlUserid
	 */
	public void setMsSqlUserid(String msSqlUserid) {
		this.msSqlUserid = msSqlUserid;
	}

	/**
	 * @param msSqlPassword セットする msSqlPassword
	 */
	public void setMsSqlPassword(String msSqlPassword) {
		this.msSqlPassword = msSqlPassword;
	}

	/**
	 * @param oraDriver セットする oraDriver
	 */
	public void setOraDriver(String oraDriver) {
		this.oraDriver = oraDriver;
	}

	/**
	 * @param oraUrl セットする oraUrl
	 */
	public void setOraUrl(String oraUrl) {
		this.oraUrl = oraUrl;
	}

	/**
	 * @param oraUserid セットする oraUserid
	 */
	public void setOraUserid(String oraUserid) {
		this.oraUserid = oraUserid;
	}

	/**
	 * @param oraPassword セットする oraPassword
	 */
	public void setOraPassword(String oraPassword) {
		this.oraPassword = oraPassword;
	}

	/**
	 * @param csvInputFolder セットする csvInputFolder
	 */
	public void setCsvInputFolder(String csvInputFolder) {
		this.csvInputFolder = csvInputFolder;
	}

	/**
	 * @param logBaseDir セットする logBaseDir
	 */
	public void setLogBaseDir(String logBaseDir) {
		this.logBaseDir = logBaseDir;
	}


}
