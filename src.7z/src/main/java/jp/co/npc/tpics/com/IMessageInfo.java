package jp.co.npc.tpics.com;

/**
 * メッセージ定数を扱うクラス。
 * @author chou
 *
 */
public interface IMessageInfo {

	public final String TFCPMSG1101 = "TPiCS連携プログラムを開始します。";
	public final String TFCPMSG1102 = "TPiCS連携プログラムが正常終了しました。";
	public final String TFCPMSG1103 = "TPiCS連携プログラムが異常終了しました。";
	// エラーメッセージ
	public final String TFCPMSG1001 = "ドライバ登録エラー(%s)";
	public final String TFCPMSG1002 = "DB接続に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1003 = "DB切断に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1004 = "DBロールバックに失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1005 = "DBロールバックを実施しました。";
	public final String TFCPMSG1006 = "DBコミットを実施しました。";
	public final String TFCPMSG1007 = "DBコミットに失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1009 = "予期しない例外発生(%s)";

	public final String TFCPMSG1011 = "リソース(%s)が見つかりません。";
	public final String TFCPMSG1012 = "環境変数取得エラー";
	public final String TFCPMSG1013 = "環境変数(%s)取得エラー";

	public final String TFCPMSG1015 = "ログディレクトリ(%s)の作成に失敗しました";

	public final String TFCPMSG1021 = "注文情報CSV出力用フォルダ(%s)が存在しません。";
	public final String TFCPMSG1022 = "注文情報CSV(%s)読み込みエラー";
	public final String TFCPMSG1023 = "注文情報CSV定義設定中エラー(%s)";
	public final String TFCPMSG1024 = "中間ＤＢ(注文情報明細テーブル)のデータ作成中エラー(%s)";
	public final String TFCPMSG1025 = "TPiCSＤＢ(XAACTテーブル)のデータ作成中エラー(%s)";
	// TODO
	public final String TFCPMSG1027 = "既登録エラー[ReceivedFileID：%s]";
	//public final String TFCPMSG1020 = "オブジェクトのクローズに失敗しました。(SQLCODE=%d)";

	// DB エラー
	public final String TFCPMSG1031 = "中間ＤＢシーケンスID(RECEIVED_FILE_ID_SEQ)の採番処理に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1032 = "中間ＤＢ(注文情報明細テーブル)へのレコード追加に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1033 = "中間ＤＢ(注文情報ヘッダテーブル)へのレコード追加に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1034 = "CSVデータ取込済の判定に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1035 = "TPiCSＤＢ(XRECE受注テーブル)の枝番検索中エラー(SQLCODE=%d)";
	public final String TFCPMSG1036 = "TPiCSＤＢ(XAACTテーブル)へのレコード追加に失敗しました。(SQLCODE=%d)";
}
