package jp.co.npc.tpics.com;

/**
 * メッセージ定数を扱うクラス。
 * @author chou
 *
 */
public interface IMessageInfo {

	// エラーメッセージ
	public final String TFCPMSG1001 = "ドライバ登録エラー(%s)";
	public final String TFCPMSG1002 = "DB接続に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1003 = "DB切断に失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1004 = "DBロールバックに失敗しました。(SQLCODE=%d)";
	public final String TFCPMSG1010 = "予期しない例外発生(%s)";

	public final String TFCPMSG1011 = "リソース(%s)が見つかりません。";
	public final String TFCPMSG1012 = "環境変数取得エラー";
	public final String TFCPMSG1013 = "環境変数(%s)取得エラー";

	public final String TFCPMSG1015 = "ログディレクトリ(%s)の作成に失敗しました";

	public final String TFCPMSG1021 = "注文情報csv出力用フォルダ(%s)が存在しません。";
	public final String TFCPMSG1022 = "注文情報csv(%s)読み込みエラー";

	public final String TFCPMSG1020 = "オブジェクトのクローズに失敗しました。(SQLCODE=%d)";
}
