package jp.co.npc.tpics.com;

/**
 * TPiCS用例外クラス
 * @author chou
 *
 */
public class TfcpException extends Exception {

    // メッセージ
    private String mMessage = "";

	// コンストラクタ
    public TfcpException(String message) {
        mMessage   = message;
    }

    // メッセージを取得
    public String getMessage() {
        return mMessage;
    }

}
