package jp.co.npc.tpics.com;

public class TfcpException extends Exception {

    // メッセージ
    private String mMessage = "";

	// コンストラクタ
    public TfcpException(String message) {
        mMessage   = message;
    }

    // メッセージを取得
    public String getMessage() {
        return mMessage;
    }

}
