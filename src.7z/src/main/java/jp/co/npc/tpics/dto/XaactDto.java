package jp.co.npc.tpics.dto;

import lombok.Data;

/**
 * XAACT定義Dto
 * @author chou
 *
 */
@Data
public class XaactDto {

	// データ区分
	private String dkubu;

	// ステータス
	private int astatus;

	// 注番
	private String porder;

	// 枝番
	private int peda;

	// アイテムコード
	private String code;

	// 得意先コード
	private String cust;

	// 指定納期日
	private String cdate;

	// 受注数量
	private int cvol;

	// 計画数量
	private int kvol;

	// 受注単価
	private int price;

	// 納品場所コード
	private String nouba;

	// 受注日
	private String jdate;

	// 営業担当者
	private String eigyou;

	// 登録日
	private String inputdate;

	// 登録者
	private String inputuser;

}
