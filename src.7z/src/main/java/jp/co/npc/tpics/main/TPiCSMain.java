package jp.co.npc.tpics.main;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.npc.tpics.com.ComUtil;
import jp.co.npc.tpics.com.DBAccess;
import jp.co.npc.tpics.com.FileZipUtil;
import jp.co.npc.tpics.com.IComConst.JOB_CODE;
import jp.co.npc.tpics.com.IMessageInfo;
import jp.co.npc.tpics.com.SystemEnv;
import jp.co.npc.tpics.com.TfcpException;

/**
 * TPiCs連携メインクラス
 * @author chou
 *
 */
public class TPiCSMain {
//	static {
//		try {
//			//ResourceBundle prop = ResourceBundle.getBundle("tpics_env");
//			//String logPath = System.getProperty("user.dir");
//			System.setProperty("LOG_DIR", "../" + ComUtil.getCurrentYM());
//		} catch (Exception e) {
//			e.printStackTrace();
//        }
//	}

//	// ログ出力クラス
	private Logger logger = null;

	/**
	 * mainメソッド
	 * @param args
	 */
    public static void main(String[] args) {

    	TPiCSMain tfcpMain = new TPiCSMain();

    	// 処理実行
    	tfcpMain.execute();
    }

	/**
	 * main処理
	 */
    public void execute() {

		DBAccess msSqlAccess = null;
		DBAccess oraAccess = null;
		SystemEnv sysEnv = null;
		Connection msSqlCon = null;
		Connection oraCon = null;
		String msg = "";
		String strLogBase = "";
		String strLogDir = "";
		int jobCode = JOB_CODE.NORMAL;

		try {

			// 環境変数
			sysEnv = new SystemEnv();
			// 環境変数の設定
			sysEnv.setEnv();

			// ログ出力ルート
			strLogBase = sysEnv.getLogBaseDir();
	        // ログ出力パス
	        strLogDir = String.format("%s%s", strLogBase, ComUtil.getCurrentYM());
	        File file = new File(strLogDir);

	        // ログ出力フォルダが存在しない場合
	        if (!file.exists()) {
	        	// ディレクトリが生成されない場合は
	            if (!file.mkdir()) {
	    			msg = String.format(IMessageInfo.TFCPMSG1015, strLogDir);
	    			System.out.println(msg);
	                return;
	            }
	        }
			// ログの配置
	        System.setProperty("LOG_DIR", strLogDir);
			logger = LoggerFactory.getLogger(TPiCSMain.class);

			// プログラム開始メッセージ出力
			msg = String.format(IMessageInfo.TFCPMSG1101);
			logger.info(msg);

			// SQLServer アクセスクラス
			msSqlAccess = new DBAccess();
			// SQLServer接続情報設定を行う
			msSqlAccess.setConfig(sysEnv.getMsSqlDriver(), sysEnv.getMsSqlUrl(), sysEnv.getMsSqlUserid(), sysEnv.getMsSqlPassword());
			// SQLServerDB接続
			msSqlCon = msSqlAccess.connect();

			// Oracleアクセスクラス
			oraAccess = new DBAccess();
			// Oracle接続情報設定を行う
			oraAccess.setConfig(sysEnv.getOraDriver(), sysEnv.getOraUrl(), sysEnv.getOraUserid(), sysEnv.getOraPassword());
			// OracleDB接続
			oraCon = oraAccess.connect();

			OrderTorokuExec orderTorokuExec = new OrderTorokuExec(msSqlCon, oraCon, sysEnv);

			// 注文情報をTPiCSに登録処理
			orderTorokuExec.execute();

			// 注文情報CSVファイルをログフォルダに保存
			FileZipUtil.copyFolder(new File(sysEnv.getCsvInputFolder()), new File(strLogDir));

		} catch (TfcpException e) {

			// 例外キャッチ(TfcpException)
			logger.debug(e.getMessage());

			jobCode = JOB_CODE.ERROR;

		} catch (Exception e) {

			// 予期しない例外
			msg = String.format(IMessageInfo.TFCPMSG1009, e.getMessage());
			logger.debug(msg);

			jobCode = JOB_CODE.ERROR;

		} finally {

			// ロールバック
			if (msSqlCon != null && oraCon != null && jobCode == JOB_CODE.ERROR) {
				try {
					// DBロールバック
					msSqlCon.rollback();
					oraCon.rollback();

					// 正常の場合、メッセージを出力
					msg = String.format(IMessageInfo.TFCPMSG1005);
					logger.debug(msg);

				} catch (SQLException e) {

					// エラーの場合、メッセージを出力
					msg = String.format(IMessageInfo.TFCPMSG1004, e.getErrorCode());
					logger.debug(msg);

					jobCode = JOB_CODE.ERROR;
				}
			}

			// DB切断
			if (msSqlAccess.disconnect() == JOB_CODE.ERROR || oraAccess.disconnect() == JOB_CODE.ERROR) {
				jobCode = JOB_CODE.ERROR;
			}

			// プログラムが正常終了した場合
			if (jobCode == JOB_CODE.NORMAL) {
				// プログラム正常終了
				msg = String.format(IMessageInfo.TFCPMSG1102);
				logger.info(msg);

			// プログラムが異常終了した場合
			} else {
				msg = String.format(IMessageInfo.TFCPMSG1103);
				logger.info(msg);
			}

			// 終了処理
			System.exit(jobCode);
		}
    }
}
