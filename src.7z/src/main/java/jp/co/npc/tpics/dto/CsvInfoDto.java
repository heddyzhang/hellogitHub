package jp.co.npc.tpics.dto;

import lombok.Data;

/**
 * 注文情報CSV定義Dto
 * @author chou
 *
 */
@Data
public class CsvInfoDto {

	private String deliver;				// 区切

	private String torokuDate;			// 登録日付

	private String seihinCode;			// 製番コード

	private String seibanName;			// 製番名

	private String orderNO;				// 受注No.

	private String seikyuCode;			// 請求先コード

	private String seikyuName1;			// 請求先名１

	private String seikyuName2;			// 請求先名２

	private String tokuisakiName1;		// 得意先名１

	private String shohinName;			// 商品名

	private String itemCode;			// 商品コード

	private String shohinName3;			// 商品名３

	private String suryo;				// 数量

	private String taniGenka;			// 単位原価

	private String nohinDate;			// 納品期日

	private String chososakiZip;		// 直送先郵便番号

	private String chososakiAddress1;	// 直送先住所１

	private String chososakiAddress2;	// 直送先住所２

	private String chososakiName1;		// 直送先名１

	private String chososakiName2;		// 直送先名２

	private String chososakiTanto;		// 直送先担当者

	private String chososakiMr;			// 直送先敬称

	private String chososakiTel;		// 直送先電話番号

	private String purchaseNO;				// 注文No.

	private String orderDate;			// 受注日付

	private String bikou;				// 備考

	private String modelArrangeCode;	// 機種／手配先コード

	private String modelArrangeName;	// 機種／手配先名

	private String jyuchuDetailID;		// 受注明細ID

	private String modificationDate;	// 修正日付

	private String shohinCategoryCode;	// 商品カテゴリコード

	private String shohinCategoryName;	// 商品カテゴリ名

}
