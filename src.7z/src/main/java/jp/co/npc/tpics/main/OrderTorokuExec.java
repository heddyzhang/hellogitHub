package jp.co.npc.tpics.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;

import jp.co.npc.tpics.com.IComConst;
import jp.co.npc.tpics.com.IMessageInfo;
import jp.co.npc.tpics.com.SystemEnv;
import jp.co.npc.tpics.com.TfcpException;

public class OrderTorokuExec {

	// コネクション
	private Connection oraConn;

	// 環境変数
	private SystemEnv sysEnv;

	// ログ出力クラス
	//private static final Logger logger = LoggerFactory.getLogger(OrderTorokuExec.class);

	/**
	 * コンストラクタ
	 * @param conn コネクション
	 */
	public OrderTorokuExec(Connection oraConn, SystemEnv env) {
		this.oraConn = oraConn;
		this.sysEnv = env;
	}

	/**
	 * main処理
	 */
	public void execute() throws TfcpException, Exception{

		BufferedReader br = null;
		String inRec = null;
		String[] inItems = null;
		String msg ="";
		String strFilePath = "";
		try {

			// 注文情報csv出力用フォルダ
			File dir = new File(sysEnv.getCsvInputFolder());

			File[] csvFiles = dir.listFiles();
			if (csvFiles == null) {
				// 注文情報csv出力用フォルダが存在しない場合
				msg = String.format(IMessageInfo.TFCPMSG1021, sysEnv.getCsvInputFolder());
				//logger.debug(msg);
				throw new TfcpException(msg);
			}

			for (File file : csvFiles) {
				if (file.isFile()) {
					// ファイルパスを取得
					strFilePath = file.getPath();

					// 注文情報データは文字コードSHIFT-JISで読み込む
					InputStream inputCsvFile = new FileInputStream(file.getPath());
					br = new BufferedReader(new InputStreamReader(inputCsvFile, IComConst.FILE_CSV_ENCODING));

					// 注文情報CSVを読み込み
					while ((inRec = br.readLine()) != null) {
					    // 項目切り出し（カンマ毎）
						inItems = inRec.split(IComConst.FILE_CSV_DELIMITER, -1);
					}
				}
			}

//			List<Map<String, Object>> list;
//			DBExecute oraExecute = new DBExecute(oraConn);
//			list = oraExecute.getResultList("select * from XAACT");
//
//			for (int i = 0; i < list.size(); i++) {
//				System.out.println(((Map<String, Object>) list.get(i)).get("DKUBU"));
//			}
		} catch (IOException ex1) {
			// 注文情報csv(%s)読み込みエラー
			msg = String.format(IMessageInfo.TFCPMSG1022, strFilePath);
			throw new TfcpException(msg);
        }catch (Exception ex2) {
			// 予期しない例外発生
			throw ex2;
		} finally {
			// リソース解放
			if (br != null) {
				br.close();
			}
		}

	}
}
