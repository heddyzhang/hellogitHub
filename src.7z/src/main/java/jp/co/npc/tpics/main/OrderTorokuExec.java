package jp.co.npc.tpics.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.npc.tpics.com.IComConst;
import jp.co.npc.tpics.com.IMessageInfo;
import jp.co.npc.tpics.com.SystemEnv;
import jp.co.npc.tpics.com.TfcpException;
import jp.co.npc.tpics.dto.OrderInfoDetailDto;
import jp.co.npc.tpics.dto.OrderInfoHeadDto;
import jp.co.npc.tpics.dto.XaactDto;
import jp.co.npc.tpics.service.OrderTorokuService;

/**
 * 注文情報を登録処理
 * @author chou
 *
 */
public class OrderTorokuExec {

	// SQLServerコネクション
	private Connection msSqlConn;

	// Oracleコネクション
	private Connection oraConn;

	// 環境変数
	private SystemEnv sysEnv;

	// ログ出力クラス
	private static final Logger logger = LoggerFactory.getLogger(OrderTorokuExec.class);

	/**
	 * コンストラクタ
	 * @param conn コネクション
	 */
	public OrderTorokuExec(Connection msSqlConn, Connection oraConn, SystemEnv env) {
		this.msSqlConn = msSqlConn;
		this.oraConn = oraConn;
		this.sysEnv = env;
	}

	/**
	 * main処理
	 */
	public void execute() throws TfcpException, Exception{

		BufferedReader br = null;
		String inRec = null;
		String[] inItems = null;
		String msg ="";
		String strFilePath = "";
		int rowNum = 0;
		int receivedFileID;
		int dataCount = 0;
		int procCount = 0;
		int errCount = 0;
		int shoriKbn = 0;
		String procStatus = "";
		String procKbn = "";
		OrderTorokuService orderTorokuService = new OrderTorokuService(msSqlConn, oraConn);
		OrderInfoHeadDto orderInfoHead = null;

		try {

			// 注文情報csv出力用フォルダ
			File dir = new File(sysEnv.getCsvInputFolder());

			File[] csvFiles = dir.listFiles();
			if (csvFiles == null) {
				// 注文情報csv出力用フォルダが存在しない場合
				msg = String.format(IMessageInfo.TFCPMSG1021, sysEnv.getCsvInputFolder());
				throw new TfcpException(msg);
			}

			for (File file : csvFiles) {
				// 拡張子が「csv」のファイルが処理対象
				if (file.isFile() && file.getName().endsWith("csv")) {
					// ファイルパスを取得
					strFilePath = file.getPath();

					// 注文情報データは文字コードSHIFT-JISで読み込む
					InputStream inputCsvFile = new FileInputStream(file.getPath());
					br = new BufferedReader(new InputStreamReader(inputCsvFile, IComConst.FILE_CSV_ENCODING));

					// データの初期化
					// 行No
					rowNum = 0;
					// 取込件数
					dataCount = 0;
					// 処理件数
					procCount = 0;
					// エラー件数
					errCount = 0;
					// シーケンスファイルＩＤを取得
					receivedFileID = orderTorokuService.getReceivedFileID();

					// 注文情報CSVを読み込み
					while ((inRec = br.readLine()) != null) {

						// CSVヘッダ以外の場合
						if (rowNum >= 1) {
						    // 項目切り出し（カンマ毎）
							inItems = inRec.split(IComConst.FILE_CSV_DELIMITER, -1);
							// 注文情報CSVを設定
							orderTorokuService.setCsvInfo(inItems);

							// 処理区分を取得
							shoriKbn = orderTorokuService.checkData();

							// 処理区分が新規の場合
							if (IComConst.SHORI_KBN.NEW == shoriKbn) {

								// 処理件数を計算
								procCount++;
								// 処理区分
								procKbn= IComConst.PROC_KBN.NEW;
								// 処理ステータス
								procStatus = IComConst.PROC_STATUS.NEWMOD;

							// 処理区分が修正の場合
							} else if (IComConst.SHORI_KBN.MOD == shoriKbn) {

								// 処理件数を計算
								procCount++;
								// 処理区分
								procKbn= IComConst.PROC_KBN.MOD;
								// 処理ステータス
								procStatus = IComConst.PROC_STATUS.NEWMOD;

							// 処理区分が登録対象外の場合
							} else {
								// エラー件数を計算
								errCount++;
								// 処理区分
								procKbn= IComConst.PROC_KBN.NA;
								// 処理ステータス
								procStatus = IComConst.PROC_STATUS.NOTOROKU;
							}

							// 注文情報明細を取得
							OrderInfoDetailDto orderInfoDetailDto = orderTorokuService.convOrderInfoDetail(receivedFileID, procKbn, procStatus);
							// 中間ＤＢに注文情報明細を登録
							orderTorokuService.insertOrderDetail(orderInfoDetailDto);

							// 新規もしくは修正のデータをTPiCS DBに登録を行う。
							if (IComConst.PROC_STATUS.NEWMOD.equals(procStatus)) {
								// Xaact情報を取得
								XaactDto xaactDto = orderTorokuService.convXaact(procKbn, orderInfoDetailDto);
								// TPiCS DBにXAACTを登録
								orderTorokuService.insertXaact(xaactDto);

							}

							// 取込件数を計算
							dataCount++;
						}

						// 次の行数
						rowNum++;
					}

					// 注文情報ヘッダを取得
					orderInfoHead = new OrderInfoHeadDto(receivedFileID, file.getName(), dataCount, procCount, errCount);
					// 中間ＤＢに注文情報ヘッダを登録
					orderTorokuService.insertOrderHead(orderInfoHead);
				}
			}

			// MDBコミット
			msSqlConn.commit();
			oraConn.commit();

			msg = String.format(IMessageInfo.TFCPMSG1006);
			logger.debug(msg);
//
//			List<Map<String, Object>> list;
//			list = oraExecute.getResultList("select * from XAACT");
//
//			for (int i = 0; i < list.size(); i++) {
//				System.out.println(((Map<String, Object>) list.get(i)).get("DKUBU"));
//			}
		} catch (IOException ex1) {
			// 注文情報csv(%s)読み込みエラー
			msg = String.format(IMessageInfo.TFCPMSG1022, strFilePath);
			throw new TfcpException(msg);

		} catch (SQLException ex1) {
			// DBコミットに失敗
			msg = String.format(IMessageInfo.TFCPMSG1007, strFilePath);
			throw new TfcpException(msg);

		} catch (TfcpException ex2) {
			// 予期しない例外発生
			throw ex2;

		} catch (Exception ex3) {
			// 予期しない例外発生
			throw ex3;

		} finally {
			// リソース解放
			if (br != null) {
				br.close();
			}
		}
	}

}
