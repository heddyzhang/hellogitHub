package jp.co.npc.tpics.com;

public interface IComConst {

	// Csvファイル文字コード
	public final String FILE_CSV_ENCODING = "SHIFT-JIS";
	// Csvファイル区切り
	public final String FILE_CSV_DELIMITER = ",";
}
