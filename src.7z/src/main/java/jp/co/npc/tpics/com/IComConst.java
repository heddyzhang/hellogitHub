package jp.co.npc.tpics.com;

/**
 * 共通定数クラス
 * @author chou
 *
 */
public interface IComConst {

	// Csvファイル文字コード
	public final String FILE_CSV_ENCODING = "SHIFT-JIS";
	// Csvファイル区切り
	public final String FILE_CSV_DELIMITER = ",";

	/* 処理ステータス(DB登録用) */
	public static class PROC_STATUS {

		public static final String NEWMOD = "10";			/* 新規、修正:10 */
		public static final String NOTOROKU = "99";		/* 登録対象外:99 */
	}

	/* 処理区分 */
	public static class SHORI_KBN {

		public static final int NEW = 1;					/* 新規 */
		public static final int MOD = 2;					/* 修正 */
		public static final int NA = 3;					/* 登録対象外 */
	}

	/* 処理区分(DB登録用) */
	public static class PROC_KBN {

		public static final String NEW = "RE-New";			/* 新規:RE-New */
		public static final String MOD = "RE-Mod";			/* 修正:RE-Mod */
		public static final String NA = "NA";					/* 登録対象外:NA */
	}

	/* ジョブコード */
	public static class JOB_CODE {
	    /* 正常終了 */
	    public static final int NORMAL	= 0;
	    /* 異常終了 */
	    public static final int ERROR	= 1;
	}

	// 登録者
	public final String LOGIN_USER = "ADMIN";

	// 日付フォーマットパターン
	public final String DATE_FORMAT_PTN_DB = "yyyyMMddHHmmss";


}
