package jp.co.npc.tpics.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ＤＢ実行クラス
 * @author chou
 *
 */
public class DBExecutor {
	/**
	 * コネクション
	 */
	private Connection conn;

	/**
	 * コンストラクタ
	 * @param conn コネクション
	 */
	public DBExecutor(Connection conn) {
		this.conn = conn;
	}

//	/**
//	 * 検索文を実行する
//	 * @param sql 検索文
//	 * @return 検索結果
//	 * @throws SQLException
//	 */
//	public List<Map<String,Object>> getResultList(String sql) throws SQLException {
//		Statement stmt = null;
//		ResultSet rs = null;
//		List<Map<String,Object>> list = null;
//
//		try {
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(sql);
//			list = new ArrayList<Map<String,Object>>();
//
//            ResultSetMetaData md = rs.getMetaData();
//            // カラム数
//            int columnCount = md.getColumnCount();
//
//			while (rs.next()) {
//
//				Map<String,Object> rowData = new HashMap<String,Object>();
//
//				for (int i = 1; i <= columnCount; i++) {
//					// Map対象に追加
//					rowData.put(md.getColumnName(i), rs.getObject(i));
//
//				}
//				// 結果リストに追加
//				list.add(rowData);
//
//			}
//		} catch (SQLException e) {
//			throw e;
//		} finally {
//            if( rs != null ){
//                rs.close();
//            }
//			if (stmt != null) {
//				stmt.close();
//			}
//		}
//
//		return list;
//	}

	/**
	 * 検索文を実行する
	 * @param sql 検索文
	 * @param args
	 * @return 検索結果 List<Map<String,Object>>
	 * @throws SQLException
	 */
	public List<Map<String,Object>> getResultList(String sql, Object... args) throws SQLException {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Map<String,Object>> list = null;

		try {
			stmt = conn.prepareStatement(sql);

			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					stmt.setObject(i + 1, args[i]);
				}
			}

			rs = stmt.executeQuery();
			list = new ArrayList<Map<String,Object>>();

            ResultSetMetaData md = rs.getMetaData();
            // カラム数
            int columnCount = md.getColumnCount();

			while (rs.next()) {

				Map<String,Object> rowData = new HashMap<String,Object>();

				for (int i = 1; i <= columnCount; i++) {
					// Map対象に追加
					rowData.put(md.getColumnName(i), rs.getObject(i));

				}
				// 結果リストに追加
				list.add(rowData);
			}
		} catch (SQLException e) {
			throw e;

		} finally {
            if( rs != null ){
                rs.close();
            }
			if (stmt != null) {
				stmt.close();
			}
		}

		return list;
	}

	/**
	 * 検索文の単一結果を取得
	 * @param sql
	 * @param args
	 * @return
	 */
	public Object getSingleValue(String sql, Object... args) throws SQLException {
		Object value = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(sql);

			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					stmt.setObject(i + 1, args[i]);
				}
			}

			rs = stmt.executeQuery();
			if (rs.next()) {
				value = rs.getObject(1);
			}
		} catch (SQLException e) {
			throw e;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return value;
	}

    /**
     * SQL文を実行する
     * @param sql UPDATE文、INSERT文、DELETE文
     * @throws SQLException
     */
    public void exeUpdSQL( String sql)throws SQLException{
        Statement stmt = null;
		try {
			stmt = this.conn.createStatement();
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			throw e;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
    }

    /**
     * SQL文を実行する
     * @param stmt
     * @throws SQLException
     */
	public void executeStmt(PreparedStatement stmt) throws SQLException {

		try {
			// 挿入SQL文を実行
			stmt.execute();

		} catch (SQLException e) {
			throw e;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}
	}

}
