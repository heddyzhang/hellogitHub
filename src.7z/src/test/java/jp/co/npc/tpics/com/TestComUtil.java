package jp.co.npc.tpics.com;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class TestComUtil {

	@Test
	public void testDateCheck() throws TfcpException, SQLException {

		DBAccess msSqlAccess = null;
		Connection msSqlCon = null;

		msSqlAccess = new DBAccess();
		msSqlAccess.setConfig("com.microsoft.sqlserver.jdbc.SQLServerDriver",
				"jdbc:sqlserver://172.16.50.161:1433;databaseName=AkinaiTpics", "sa", "TPiCSlab3");
		msSqlCon = msSqlAccess.connect();

		List<Map<String, Object>> resultlist;
		DBExecutor msSqlExecutor = new DBExecutor(msSqlCon);
		//resultlist = msSqlExecutor.getResultList("SELECT CONVERT(VARCHAR(100), ModificationDate, 21) ModificationDate from ORDER_INFO_DETAIL");
		resultlist = msSqlExecutor.getResultList("SELECT ModificationDate from ORDER_INFO_DETAIL");

		for (int i = 0; i < resultlist.size(); i++) {
			Object obj =((Map<String, Object>) resultlist.get(i)).get("ModificationDate");
			String modifyDate = obj == null ? null : obj.toString();
			assertThat(ComUtil.dateCheck(modifyDate, "2018-08-23 11:18:07.510"), is(-1));
		}
	}
}
