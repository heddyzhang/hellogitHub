package jp.co.npc.tpics.com;
import org.junit.Test;

import jp.co.npc.tpics.com.FileZipUtil;

public class TestFileUtil {

	@Test
	public void testZipDirectory( ) throws Exception{
		FileZipUtil addZip = new FileZipUtil();
		addZip.zipDirectory("../201808", "../201808.zip");
	}
}
