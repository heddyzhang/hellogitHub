/*
 * ����LDAP�F�؃T���v���v���O����
 * Copyright (C) Toshiba I.S. Corporation All rights reserved.
 */
package jp.co.toshiba.hcm.security;
import javax.naming.*;
import javax.naming.directory.*;
import java.util.*;
import jp.co.toshiba.tiger.config.TigerUserEnvProperty;
import jp.co.toshiba.hcm.util.UZAStringUtils;

public class LdapAuth {
	private static boolean DEBUG = false;
	private static final int AUTH_OK = 0;
	private static final int AUTH_USER_NG = 1;
	private static final int AUTH_APP_NG = 2;
	private static final int AUTH_USER_NOT_FOUND = 5;
	private static final int AUTH_NG = 9;

//    public LdapAuth(String host, int port, String appDN, String apppw, String baseDN, String usrid, String usrpw) {
//	int rc = checkAuth(host, port, appDN, apppw, baseDN, usrid, usrpw);
//	if (DEBUG) {
//	    System.out.println("rc = " + rc);
//	}
//    }


/*
 * �F�؎菇
 */
	public int checkAuth( String usrid, String usrpw) {

		String host = UZAStringUtils.nullToEmpty(TigerUserEnvProperty.getUserProperty("ldap.host"));
		String port = UZAStringUtils.nullToEmpty(TigerUserEnvProperty.getUserProperty("ldap.port"));
		String appDN = UZAStringUtils.nullToEmpty(TigerUserEnvProperty.getUserProperty("ldap.application.dn"));
		String apppw = UZAStringUtils.nullToEmpty(TigerUserEnvProperty.getUserProperty("ldap.application.password"));
		String baseDN = UZAStringUtils.nullToEmpty(TigerUserEnvProperty.getUserProperty("ldap.base.dn"));

		if ((usrid == null) || (usrid.trim().length() == 0))
			return AUTH_NG;
		if ((usrpw == null) || (usrpw.trim().length() == 0))
			return AUTH_NG;

		// (1)�A�v���P�[�V����ID(DN)���Z�b�g���F��

		Hashtable env = new Hashtable();
//		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
//		env.put(Context.PROVIDER_URL, "ldap://ldap1c.tis.toshiba.co.jp:389/");
//		env.put(Context.SECURITY_AUTHENTICATION, "simple");
//		env.put(Context.SECURITY_PRINCIPAL, "uid=HAMAID01,ou=applications,o=TOSHIBA-GROUP");
//		env.put(Context.SECURITY_CREDENTIALS, "hama999");

		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://" + host + ":" + port + "/");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, appDN);
		env.put(Context.SECURITY_CREDENTIALS, apppw);

		//SSL�̏ꍇ�͉��L���K�v
		//java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider()); 
		//env.put(Context.SECURITY_PROTOCOL, "ssl");

		DirContext ctx;

		try {
			ctx = new InitialDirContext(env);
		}
		catch (Exception e) {
			return AUTH_APP_NG;
		}

		// (2)���[�UID���烆�[�UDN������
		SearchControls ctls = new SearchControls();
		ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		String userDN = "";
		try {
//			NamingEnumeration result = ctx.search("o=TOSHIBA-GROUP", "(uid=" + usrid + ")", ctls);
			NamingEnumeration result = ctx.search(baseDN, "(uid=" + usrid + ")", ctls);
			if ((result == null) || (!result.hasMore())) {
				result.close();
				ctx.close();
				return AUTH_USER_NOT_FOUND;
			}
			SearchResult sr = (SearchResult) result.next();
			userDN = sr.getName();
			result.close();
		}
		catch (Exception e) {
			return AUTH_NG;
		}

		try {
			ctx.close();
		}
		catch (Exception e) {
			return AUTH_NG;
		}

		if (DEBUG) {
			System.out.println("userDN = " + userDN);
		}

		// (3)���[�U��DN�ƃp�X���[�h�ŔF��
//		env.put(Context.SECURITY_PRINCIPAL, userDN + ", " + "o=TOSHIBA-GROUP");
		env.put(Context.SECURITY_PRINCIPAL, userDN + ", " + baseDN);
		env.put(Context.SECURITY_CREDENTIALS, usrpw);

		try {
			ctx = new InitialDirContext(env);
			ctx.close();
			return AUTH_OK;
		}
		catch (Exception e) {
			return AUTH_USER_NG;
		}
    }

//    public static void main(String[] args) {
//	if (args.length != 7) {
//	    System.out.println("usage: LdapAuth <host> <port> <appId> <appPasswd> <baseDN> <usrid> <passwd>");
//	    System.exit(0);
//	}
//	String host = args[0];
//	int port = Integer.parseInt(args[1]);	//SSL=636, Non-SSL=389
//	String appId = args[2];
//	String apppwd = args[3];
//	String baseDn = args[4];
//	String usrid = args[5];
//	String usrpw = args[6];
//	LdapAuth.DEBUG = true;
//	LdapAuth ldapAuth = new LdapAuth(host, port, appId, apppwd, baseDn, usrid, usrpw);
//    }
}
