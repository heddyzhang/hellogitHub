package jp.co.toshiba.hcm.forms;

import jp.co.toshiba.tiger.base.TigerActionForm;

/**
 * Cookie���O�C�����Form�N���X
 * @author K.Zheng
 * @since 2013.06
 *
 */
public class HCM02105Form extends TigerActionForm {
	private String zbn;        //�}��;
	private String hen_kai;     //�ύX��;
	private String userid;      //���[�UID
	private String pswd;        //�p�X���[�h
	
	/**
	 * @return hen_kai
	 */
	public String getHen_kai() {
		return hen_kai;
	}
	/**
	 * @param hen_kai �ݒ肷�� hen_kai
	 */
	public void setHen_kai(String hen_kai) {
		this.hen_kai = hen_kai;
	}
	/**
	 * @return pswd
	 */
	public String getPswd() {
		return pswd;
	}
	/**
	 * @param pswd �ݒ肷�� pswd
	 */
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	/**
	 * @return userid
	 */
	public String getUserid() {
		return userid;
	}
	/**
	 * @param userid �ݒ肷�� userid
	 */
	public void setUserid(String userid) {
		this.userid = userid;
	}
	/**
	 * @return zbn
	 */
	public String getZbn() {
		return zbn;
	}
	/**
	 * @param zbn �ݒ肷�� zbn
	 */
	public void setZbn(String zbn) {
		this.zbn = zbn;
	}	
	
}
